import 'package:app_ropa/models/pedidoModel.dart';
import 'package:app_ropa/models/userModel.dart';
import 'package:app_ropa/service/pedidoServicio.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class PedidoRepository {
  final PedidoService _pedidoService;

  PedidoRepository({PedidoService? pedidoService})
      : _pedidoService = pedidoService ?? PedidoService();

  /// Guarda el pedido en Firebase y en Oracle
  Future<void> agregarPedido(Pedido pedido, Usuario usuario) async {
    try {
      // Guardar en Firebase
      await _pedidoService.guardarPedido(pedido);

      // Guardar también en Oracle
      await _guardarEnOracle(pedido, usuario);
    } catch (e) {
      throw Exception('Error al guardar el pedido: $e');
    }
  }

  /// Envía el pedido y el cliente a Oracle
Future<void> _guardarEnOracle(Pedido pedido, Usuario usuario) async {
  final url = Uri.parse('http://10.0.2.2:3000/insertar-pedido');

  final data = {
    "usuario": {
      "nombre": usuario.nombre,
      "direccion": usuario.direccion,
      "email": usuario.email,
      "telefono": usuario.telefono,
      "tipo": usuario.tipo,
    },
    "factura": {
      "monto_total": pedido.total,
      "fecha_emision": DateTime.now().toIso8601String().substring(0, 10),
      "estado_pago": "pendiente",
      "metodo_pago": "tarjeta",
      "divisa": "PEN"
    },
    "pedido": {
      "fecha_ingreso": DateTime.now().toIso8601String().substring(0, 10),
      "estado_pedido": "procesando",
      "total": pedido.total,
      "fecha_entrega_estimada": DateTime.now().add(Duration(days: 7)).toIso8601String().substring(0, 10)
    },
    "items": [
      {
        "cantidad": pedido.cantidad,
        "talla": pedido.talla,
        "color": pedido.color,
        "precio_unitario": pedido.precio
      }
    ]
  };

  final response = await http.post(
    url,
    headers: {'Content-Type': 'application/json'},
    body: jsonEncode(data),
  );

  if (response.statusCode != 200) {
    throw Exception('Oracle error: ${response.body}');
  } else {
    print('✅ Pedido completo guardado en Oracle');
  }
}


  /// Trae todos los pedidos desde Firebase
  Future<List<Pedido>> obtenerTodosLosPedidos() async {
    try {
      return await _pedidoService.obtenerPedidos();
    } catch (e) {
      throw Exception('Error al obtener los pedidos: $e');
    }
  }

  /// Elimina un pedido de Firebase
  Future<void> eliminarPedido(String id) async {
    try {
      await _pedidoService.eliminarPedido(id);
    } catch (e) {
      throw Exception('Error al eliminar el pedido: $e');
    }
  }
}
