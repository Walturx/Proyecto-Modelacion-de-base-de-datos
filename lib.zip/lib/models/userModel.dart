class Usuario {
  int ?id;
  String nombre;
  String direccion;
  String email;
  String telefono;
  String tipo;

  Usuario({
    required this.id,
    required this.nombre,
    required this.direccion,
    required this.email,
    required this.telefono,
    required this.tipo,
  });

  // Método para convertir un Usuario en un mapa (útil para Firebase, JSON, etc.)
  Map<String, dynamic> toMap() {
    return {
      'nombre': nombre,
      'direccion': direccion,
      'email': email,
      'telefono': telefono,
      'tipo': tipo,
    };
  }

  // Constructor desde un mapa (por ejemplo, desde Firestore o JSON)
  factory Usuario.fromMap(Map<String, dynamic> map) {
    return Usuario(
      id: map['id'],
      nombre: map['nombre'],
      direccion: map['direccion'],
      email: map['email'],
      telefono: map['telefono'].toString(), // Por si viene como número
      tipo: map['tipo'],
    );
  }

  @override
  String toString() {
    return 'Usuario(id: $id, nombre: $nombre, direccion: $direccion, email: $email, telefono: $telefono, tipo: $tipo)';
  }
}
