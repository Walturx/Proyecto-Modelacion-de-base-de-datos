import 'package:app_ropa/models/userModel.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';


class UsuarioService {
  final CollectionReference usuariosRef =
      FirebaseFirestore.instance.collection('usuarios');

  // Crear o registrar un usuario
  Future<void> agregarUsuario(Usuario usuario) async {
  final collection = FirebaseFirestore.instance.collection('Users');

  await collection.add(usuario.toMap()); // no usa .doc(id)
}


  // Obtener todos los usuarios
  Future<List<Usuario>> obtenerUsuarios() async {
    try {
      QuerySnapshot snapshot = await usuariosRef.get();
      return snapshot.docs
          .map((doc) => Usuario.fromMap(doc.data() as Map<String, dynamic>))
          .toList();
    } catch (e) {
      print('Error al obtener usuarios: $e');
      return [];
    }
  }

  // Obtener un usuario por ID
  Future<Usuario?> obtenerUsuarioPorId(int id) async {
    try {
      DocumentSnapshot doc = await usuariosRef.doc(id.toString()).get();
      if (doc.exists) {
        return Usuario.fromMap(doc.data() as Map<String, dynamic>);
      }
    } catch (e) {
      print('Error al obtener usuario por ID: $e');
    }
    return null;
  }

  // Actualizar usuario
  Future<void> actualizarUsuario(Usuario usuario) async {
    try {
      await usuariosRef.doc(usuario.id.toString()).update(usuario.toMap());
    } catch (e) {
      print('Error al actualizar usuario: $e');
    }
  }

  // Eliminar usuario
  Future<void> eliminarUsuario(int id) async {
    try {
      await usuariosRef.doc(id.toString()).delete();
    } catch (e) {
      print('Error al eliminar usuario: $e');
    }
  }
}