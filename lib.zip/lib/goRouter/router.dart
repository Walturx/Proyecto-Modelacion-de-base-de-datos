import 'package:app_ropa/models/pedidoModel.dart';
import 'package:app_ropa/models/ropaModel.dart';
import 'package:app_ropa/models/userModel.dart';
import 'package:app_ropa/views/cartScreen.dart';
import 'package:app_ropa/views/factura.dart';
import 'package:app_ropa/views/homeScreen.dart';
import 'package:app_ropa/views/productScreen.dart';
import 'package:app_ropa/views/userScreen.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

final _rootNavigatorKey = GlobalKey<NavigatorState>(debugLabel: 'root');

final router = GoRouter(
  navigatorKey: _rootNavigatorKey,
  initialLocation: Routes.register, 
  routes: [
    // Ruta principal
    GoRoute(
      path: Routes.register,
      builder: (context, state) => const Userscreen(),
    ),

    // Ruta a la pantalla de producto

 GoRoute(
  path: Routes.home,
  builder: (context, state) {
    if (state.extra == null || state.extra is! Usuario) {
      return const Scaffold(
        body: Center(child: Text('⚠️ Usuario no enviado')),
      );
    }

    final usuario = state.extra as Usuario;
    return Homescreen(usuario: usuario);
  },
),



   GoRoute(
  path: Routes.ropa,
  builder: (context, state) {
    final map = state.extra as Map<String, dynamic>;
    final producto = map['producto'] as Producto;
    final usuario = map['usuario'] as Usuario;
    return ProductScreen(producto: producto, usuario: usuario);
  },
),


    GoRoute(
  path: Routes.cartPage,
  builder: (context, state) {
    final usuario = state.extra as Usuario;
    return Cartscreen(usuario: usuario); // ⬅️ pásalo aquí
  },
),
   GoRoute(
  path: Routes.facturaPage,
  builder: (context, state) {
    final pedido = state.extra as List<Pedido>;
    return FacturaScreen(pedidos: pedido);
  },
),
  ],
);

class Routes {
  Routes._();
  static const register = '/register';
  static const home = '/home';
  static const ropa = '/ropa';
  static const splash = '/splash';
  static const cartPage = '/cart';
  static const facturaPage = '/factura';
}